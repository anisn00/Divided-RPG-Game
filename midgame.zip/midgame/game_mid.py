import pygame

pygame.init()
font = pygame.font.Font('freesansbold.ttf', 24)
screen = pygame.display.set_mode([800, 500])
timer = pygame.time.Clock()
background_image = pygame.image.load('background.jpg')  # Charger l'image de fond
messages = ['vous : maintenant que je suis sortie d\'ici je dois ',
            'vous : allez cherchez les artéfact ',
            'vous : et je vais commencer par le colier du feu',
            'vous : je suppose qu\'il se trouve en haut de cette tour de feu',
            'vous : j\'y vais de suite !']
snip = font.render('', True, 'white')
counter = 0
speed = 3
done = False
active_message = 0  # Variable pour suivre le message actif

run = True
while run:
    screen.blit(background_image, (-80, -180))  # Afficher l'image de fond
    timer.tick(60)
    pygame.draw.rect(screen, (0, 0, 0), [0, 300, 800, 200])  # Zone de texte
    message = messages[active_message]  # Sélection du message actif
    if counter < speed * len(message):
        counter += 1
    elif counter >= speed * len(message):
        done = True
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN and done and active_message < len(messages) - 1:
                active_message += 1  # Passer au message suivant
                done = False
                counter = 0
    snip = font.render(message[:counter // speed], True, (255, 255, 255))  # Couleur blanche
    screen.blit(snip, (10, 310))  # Affichage du texte
    pygame.display.flip()

pygame.quit()

