import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the display
WIDTH, HEIGHT = 400, 200
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Red 'i' Example")

# Define colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Load font
font = pygame.font.Font("D:/Wael/vs code folder/project2/Vampire Wars.ttf", 48)  # Change the path to the desired font file

# Render the text
text = "divided"
text_rendered = font.render(text, True, WHITE)

# Find the position of the second 'i'
i_positions = [pos for pos, char in enumerate(text) if char == 'i']
second_i_position = i_positions[1]

# Split the text into two parts
text_part1 = text[:second_i_position]
text_part2 = text[second_i_position:second_i_position + 1]
text_part3 = text[second_i_position + 1:]

# Render the text parts separately
part1_rendered = font.render(text_part1, True, WHITE)
part2_rendered = font.render(text_part2, True, RED)
part3_rendered = font.render(text_part3, True, WHITE)

# Calculate positions
part1_width = part1_rendered.get_width()
part2_width = part2_rendered.get_width()
part3_width = part3_rendered.get_width()
x = (WIDTH - (part1_width + part2_width + part3_width)) // 2
y = HEIGHT // 2 - text_rendered.get_height() // 2

# Blit the text to the screen
screen.blit(part1_rendered, (x, y))
screen.blit(part2_rendered, (x + part1_width, y))
screen.blit(part3_rendered, (x + part1_width + part2_width, y))

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()
